//
//  CDReadingSession.swift
//  ReadLay
//
//  Created by Mateo Arratia on 8/22/25.
//


import Foundation
import CoreData

@objc(CDReadingSession)
public class CDReadingSession: NSManagedObject {}
