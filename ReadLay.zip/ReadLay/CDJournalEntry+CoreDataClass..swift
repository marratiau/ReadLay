//
//  CDJournalEntry.swift
//  ReadLay
//
//  Created by Mateo Arratia on 8/22/25.
//


import Foundation
import CoreData

@objc(CDJournalEntry)
public class CDJournalEntry: NSManagedObject {}
