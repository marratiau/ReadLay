//
//  CoreDataBridge.swift
//  ReadLay
//
//  Created by Mateo Arratia on 8/22/25.
//


import Foundation
import CoreData

enum CoreDataBridge {
    // MARK: Book (struct Book ↔ CDBook)
    static func upsertBook(from model: Book, in ctx: NSManagedObjectContext) throws -> CDBook {
        let req: NSFetchRequest<CDBook> = CDBook.fetchRequest()
        req.predicate = NSPredicate(format: "id == %@", model.id as CVarArg)
        req.fetchLimit = 1
        let existing = try ctx.fetch(req).first
        let obj = existing ?? CDBook(context: ctx)
        obj.id = model.id
        obj.title = model.title
        obj.author = model.author
        obj.totalPages = Int32(model.totalPages)
        obj.coverImageName = model.coverImageName
        obj.coverImageURL = model.coverImageURL
        if existing == nil { obj.currentPage = 0 }
        return obj
    }

    static func toModel(_ obj: CDBook) -> Book {
        let prefs = ReadingPreferences.load(for: obj.id)
            ?? ReadingPreferences.defaultForBook(totalPages: Int(obj.totalPages))
        return Book(
            id: obj.id,
            title: obj.title,
            author: obj.author,
            totalPages: Int(obj.totalPages),
            coverImageName: obj.coverImageName,
            coverImageURL: obj.coverImageURL,
            readingPreferences: prefs
        )
    }

    // MARK: Reading Session
    static func makeSession(for book: CDBook, pages: Int, minutes: Int, note: String? = nil, in ctx: NSManagedObjectContext) -> CDReadingSession {
        let s = CDReadingSession(context: ctx)
        s.id = UUID()
        s.date = Date()
        s.pagesRead = Int32(pages)
        s.minutes = Int32(minutes)
        s.note = note
        s.book = book
        book.currentPage = max(book.currentPage, book.currentPage + Int32(pages))
        return s
    }

    // MARK: Journal Entry
    static func addJournalEntry(book: CDBook, text: String, mood: String? = nil, extra: Data? = nil, in ctx: NSManagedObjectContext) -> CDJournalEntry {
        let e = CDJournalEntry(context: ctx)
        e.id = UUID()
        e.createdAt = Date()
        e.text = text
        e.mood = mood
        e.extraJSON = extra
        e.book = book
        return e
    }

    // Optional: map CDJournalEntry → your struct JournalEntry (for ViewModel lists)
    static func toJournalStruct(_ e: CDJournalEntry) -> JournalEntry {
        JournalEntry(
            id: e.id,
            bookId: e.book.id,
            bookTitle: e.book.title,
            bookAuthor: e.book.author,
            date: e.createdAt,
            comment: e.text,
            engagementEntries: [],   // parse e.extraJSON if you store them
            sessionDuration: nil,    // parse from extraJSON if needed
            pagesRead: nil,          // parse from extraJSON if needed
            startingPage: nil,
            endingPage: nil
        )
    }
}
